public class ATM {
  ATMState state;
  ATMRoom atmRoom;

  public ATM() {
    state = new IdleState();
    ATMState.atm = this;
    atmRoom = ATMSetup.getAtmRoom();
  }

  public void setATMState(ATMState s) {
    this.state = s;
  }

  public ATMState getAtmState() {
    return this.state;
  }
}
