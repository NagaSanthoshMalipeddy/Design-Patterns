public class ATMRoom {
  int balance;
  int HundredNotes;
  int Five100Notes;

  public ATMRoom() {
    initialize();
  }

  public void initialize() {
    balance = 5400;
    HundredNotes = 10;
    Five100Notes = 4;
  }

  public int getHundredNotes() {
    return HundredNotes;
  }

  public void setHundredNotes(int hundredNotes) {
    HundredNotes = hundredNotes;
  }

  public int getFive100Notes() {
    return Five100Notes;
  }

  public void setFive100Notes(int five100Notes) {
    Five100Notes = five100Notes;
  }

  public int getBalance() {
    return balance;
  }

  public void setBalance(int balance) {
    this.balance = balance;
  }

}