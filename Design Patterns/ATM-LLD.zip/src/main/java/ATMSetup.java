class ATMSetup {
  public static ATMRoom room;
  public static CashHandler c;

  public static ATMRoom getAtmRoom() {
    if (room != null) {
      return room;
    }
    room = new ATMRoom();
    return room;
  }

  public static void setCashHandlers() {
    c = new FiveHundredHandler(new HundredHandler());
  }
}