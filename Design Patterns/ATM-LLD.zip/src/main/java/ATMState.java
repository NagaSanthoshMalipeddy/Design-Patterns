public abstract class ATMState {
  public static Card c;
  public static ATM atm;

  public void insertCard(Card c) {
    System.out.println("Exception during insertion");
    exitATM();
  }

  public void authentication() {
    System.out.println("Exception during authentication");
    exitATM();
  }

  public void chooseOperation(String op) {
    System.out.println("Exception during choosing operation");
    exitATM();
  }

  public void withdraw(int amount) {
    System.out.println("Exception during withdraw");
    exitATM();
  }

  private void removeCard() {
    c = null;
    atm.setATMState(new IdleState());
    System.out.println("Please Collect Your Card");
  }

  public void exitATM() {
    removeCard();
    System.out.println("Thank You !!!");
    atm.setATMState(new IdleState());
  }
}