public class AuthenticationState extends ATMState {
  public AuthenticationState() {
    System.out.println("AUTHENTICATING....");
  }

  public void authentication() {
    if (c.cardNum != 0 && c.cvv != 0 && c.expiryyear != 0) {
      System.out.println("Authenticated Successfully");
      atm.setATMState(new ChooseOperationState());
    } else {
      exitATM();
    }
  }

}