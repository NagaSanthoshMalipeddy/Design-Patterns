public class BankAccount {
  String holderName;
  String AccNum;
  int balance;

  public BankAccount(String holderName, String AccNum, int balance) {
    this.holderName = holderName;
    this.AccNum = AccNum;
    this.balance = balance;
  }

  public String getHolderName() {
    return holderName;
  }

  public void setHolderName(String holderName) {
    this.holderName = holderName;
  }

  public String getAccNum() {
    return AccNum;
  }

  public void setAccNum(String accNum) {
    AccNum = accNum;
  }

  public int getBalance() {
    return balance;
  }

  public void setBalance(int balance) {
    this.balance = balance;
  }

}