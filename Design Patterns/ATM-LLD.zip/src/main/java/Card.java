public class Card {
  int cardNum;
  int cvv;
  int expiryyear;
  BankAccount bankAccount;

  public Card(int cardNum, int cvv, int expiryyear, BankAccount bankAccount) {
    this.cardNum = cardNum;
    this.cvv = cvv;
    this.expiryyear = expiryyear;
    this.bankAccount = bankAccount;
  }

  public int checkBalance(){
    return bankAccount.getBalance();
  }

  public boolean deductMoney(int money){
    if(money<=bankAccount.getBalance()){
      bankAccount.setBalance(bankAccount.getBalance()-money);
      return true;
    }
    return false;
  }

  public int getCardNum() {
    return cardNum;
  }

  public void setCardNum(int cardNum) {
    this.cardNum = cardNum;
  }

  public int getCvv() {
    return cvv;
  }

  public void setCvv(int cvv) {
    this.cvv = cvv;
  }

  public int getExpiryyear() {
    return expiryyear;
  }

  public void setExpiryyear(int expiryyear) {
    this.expiryyear = expiryyear;
  }

  public BankAccount getBankAccount() {
    return bankAccount;
  }

  public void setBankAccount(BankAccount bankAccount) {
    this.bankAccount = bankAccount;
  }

}