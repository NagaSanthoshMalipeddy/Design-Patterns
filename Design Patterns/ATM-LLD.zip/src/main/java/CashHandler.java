public abstract class CashHandler {
  CashHandler next;
  public static ATMRoom room = ATMSetup.getAtmRoom();

  public CashHandler(CashHandler c) {
    setNextHandler(c);
  }

  public CashHandler() {
  }

  public void setNextHandler(CashHandler nextHandler) {
    this.next = nextHandler;
  }

  public void withdraw(int amount) {
    next.withdraw(amount);
  }
}