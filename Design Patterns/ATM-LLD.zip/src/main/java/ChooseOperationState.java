public class ChooseOperationState extends ATMState {
  public ChooseOperationState() {
    System.out.println("Choose your operation");
  }

  public void chooseOperation(String op) {
    if (op.equals("withdraw")) {
      atm.setATMState(new WithdrawState());
    } else {
      System.out.println("ATM doesn't support other operations currently");
      exitATM();
    }
  }
}