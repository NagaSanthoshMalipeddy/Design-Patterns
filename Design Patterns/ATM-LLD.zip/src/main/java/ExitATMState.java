public class ExitATMState extends ATMState {
  public ExitATMState() {
    System.out.println("Transaction is successfull");
    exitATM();
  }
}