public class FiveHundredHandler extends CashHandler{
  public FiveHundredHandler(CashHandler h){
    super(h);
  }
  public void withdraw(int amount){
    int total = amount / 500;
    int noOfNotes=0;
    if(total <= room.getFive100Notes()){
      noOfNotes=total;
    }
    else{
      noOfNotes=room.getFive100Notes();
    }
    room.setFive100Notes(room.getFive100Notes()-noOfNotes);
    room.setBalance(room.getBalance()-noOfNotes*500);
    System.out.println("Dispensing "+noOfNotes+" of 500 notes");
    amount-=noOfNotes*500;
    if(amount>0){
      next.withdraw(amount);
    }
  }
  
}