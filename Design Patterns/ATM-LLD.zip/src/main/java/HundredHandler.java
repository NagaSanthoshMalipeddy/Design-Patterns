public class HundredHandler extends CashHandler {
  public HundredHandler(CashHandler h) {
    super(h);
  }

  public HundredHandler() {
  }

  public void withdraw(int amount) {
    int total = amount / 100;
    int noOfNotes = 0;
    if (total <= room.getHundredNotes()) {
      noOfNotes = total;
    } else {
      noOfNotes = room.getHundredNotes();
    }
    room.setHundredNotes(room.getHundredNotes() - noOfNotes);
    room.setBalance(room.getBalance() - noOfNotes * 100);
    System.out.println("Dispensing " + noOfNotes + " of 100 notes");
    amount -= noOfNotes * 100;
    if (amount > 0) {
      if (next == null) {
        System.out.println("unable to process!!!");
        return;
      }
      next.withdraw(amount);
    }
  }

}