public class IdleState extends ATMState {
  public IdleState() {
    System.out.println("ATM is in idle state");
  }

  public void insertCard(Card c) {
    ATMState.c = c;
    System.out.println("Card has been inserted successfully");
    atm.setATMState(new AuthenticationState());
  }
}