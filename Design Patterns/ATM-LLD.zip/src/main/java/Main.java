// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {
    ATM atm = new ATM();
    System.out.println(atm.getAtmState());
    atm.getAtmState().insertCard(new Card(1, 2, 3, new BankAccount("sunny", "5458751551841", 8000)));
    atm.getAtmState().authentication();
    atm.getAtmState().chooseOperation("withdraw");
    atm.getAtmState().withdraw(5350);
    ;
  }

  // @Test
  // void addition() {
  // assertEquals(2, 1 + 1);
  // }
}