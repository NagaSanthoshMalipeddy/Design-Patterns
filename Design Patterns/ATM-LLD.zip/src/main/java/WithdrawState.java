public class WithdrawState extends ATMState {
  CashHandler ch;
  public WithdrawState() {
    System.out.println("ATM is in withdraw state");
  }

  public void withdraw(int amount) {
    if (c.getBankAccount().getBalance() < amount) {
      System.out.println("Insuffiecient Balance");
      exitATM();
    } else {
      if (atm.atmRoom.getBalance() < amount) {
        System.out.println("ATM has insufficient balance");
        exitATM();
      } else {
        ATMSetup.setCashHandlers();
        ATMSetup.c.withdraw(amount);
        System.out.println("withdraw successfull");
        atm.setATMState(new ExitATMState());
      }
    }
  }
}